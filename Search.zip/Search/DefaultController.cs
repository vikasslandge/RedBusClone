﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebServiceWork.Controllers
{
    public class DefaultController : Controller
    {
        public ProviderServiceReference.ProvidersWebServiceSoapClient soapClient = new ProviderServiceReference.ProvidersWebServiceSoapClient();

        // GET: Default
        public ActionResult Search()
        {
            ViewBag.Source = new SelectList(soapClient.GetCityDetails(), "CityId", "CityName");
            ViewBag.Destination = new SelectList(soapClient.GetCityDetails(), "CityId", "CityName");
            
            return View();
        }

        [HttpPost]
        public ActionResult SearchList(FormCollection collection)
        {
           var result= soapClient.GetRouteDetails(Convert.ToInt32(collection["Source"]), Convert.ToInt32(collection["Destination"]), Convert.ToDateTime(collection["DateOfJourney"]));
            return View(result.ToList());
        }
        
        public ActionResult AddTicket(FormCollection collection)
        {
            ViewBag.id = collection["RouteId"];
            ViewBag.MaxSeat = collection["selectedSeat"];
            // var result = soapClient.AddTicketDetails(Convert.ToInt32(collection["RouteId"]), 3);
            return View();
        }

        public ActionResult Passenger()
        {
            return View(soapClient.AddPassanger.ToString())
        }
    }
}