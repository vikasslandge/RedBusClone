﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebServiceWork.Controllers
{
    public class DefaultController : Controller
    {
        public ProviderServiceReference.ProvidersWebServiceSoapClient soapClient = new ProviderServiceReference.ProvidersWebServiceSoapClient();

        // GET: Default
        public ActionResult Search()
        {
            ViewBag.Source = new SelectList(soapClient.GetCityDetails(), "CityId", "CityName");
            ViewBag.Destination = new SelectList(soapClient.GetCityDetails(), "CityId", "CityName");
            
            return View();
        }

        [HttpPost]
        public ActionResult SearchList(FormCollection collection)
        {
           var result= soapClient.GetRouteDetails(Convert.ToInt32(collection["Source"]), Convert.ToInt32(collection["Destination"]), Convert.ToDateTime(collection["DateOfJourney"]));
            return View(result.ToList());
        }
        
        public ActionResult AddTicket(FormCollection collection)
        {
            ViewBag.id = collection["RouteId"];
            ViewBag.MaxSeat = 2;
            // var result = soapClient.AddTicketDetails(Convert.ToInt32(collection["RouteId"]), 3);
            return View();
        }


        public ActionResult BookSeat()
        {
            return View();
        }

        [HttpPost]
        public ActionResult BookSeat(FormCollection collection)
        {
            var result = soapClient.BookSeat( Convert.ToInt32(collection["SeatNo"]), Convert.ToInt32(collection["BusId"]), collection["seatStatus"]);
            return View();
        }

        public ActionResult Passenger()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Passenger(FormCollection collection)
        {
            var result = soapClient.AddPassanger(collection["Name"], Convert.ToInt32(collection["Age"]), collection["Gender"], collection["Phone"], Convert.ToInt32(collection["SeatNo"]));
            return View();
        }

    }
}