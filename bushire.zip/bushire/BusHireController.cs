﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusHire.Models;

namespace BusHire.Controllers
{
    public class BusHireController : Controller
    {
        BusHireEntities entity = new BusHireEntities();
        // GET: BusHire
        public ActionResult HireDetails()
        {
            DateTime date = DateTime.Now;
            
            TempData["currentDate"] = date.Year + "-0" + date.Month + "-0" +date.Day;
           
            ViewBag.Source = new SelectList(entity.Cities.ToList(), "CityId", "CityName");
            ViewBag.Destination = new SelectList(entity.Cities.ToList(), "CityId", "CityName");
            return View();
        }

        [HttpPost]
        public ActionResult SaveDetails(FormCollection collection)
        {
            BookDetail book = new BookDetail();

            //book.BookId = b.BookId;
            book.Name = collection["Name"];
            book.Contact = Convert.ToInt64(collection["Contact"]);
            entity.BookDetails.Add(book);
            entity.SaveChanges();

            HireDetail hire = new HireDetail();

            hire.StartDate = Convert.ToDateTime(collection["StartDate"]).Date;
            hire.EndDate = Convert.ToDateTime(collection["EndDate"]).Date;
            hire.Type = collection["Type"];
            hire.Capacity = Convert.ToInt32(collection["Capacity"]);
            hire.Source = Convert.ToInt32(collection["Source"]);
            hire.Destination = Convert.ToInt32(collection["Destination"]);
            hire.Return = collection["Return"];
            hire.BookId = book.BookId;

            entity.BookDetails.Add(book);
            
            entity.HireDetails.Add(hire);
            entity.SaveChanges();

            return RedirectToAction("Success", "BusHire");
        }
        public ActionResult Success()
        {
            return View();
        }
    }
}